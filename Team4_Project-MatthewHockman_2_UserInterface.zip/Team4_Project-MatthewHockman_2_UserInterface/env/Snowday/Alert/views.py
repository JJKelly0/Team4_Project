from django.shortcuts import  render, redirect
from .forms import NewUserForm, accountForm, loginForm, AuthenticationForm
from django.contrib.auth import login, authenticate, get_user_model
from django.contrib import messages
from django.http import HttpResponse

def register_request(request):
	if request.method == "POST":
		form = NewUserForm(request.POST)
		if form.is_valid():
			user = form.save()
			login(request, user)
			messages.success(request, "Registration successful." )
			return redirect("register_request")
		messages.error(request, "Unsuccessful registration. Invalid information.")
	form = NewUserForm()
	return render (request=request, template_name="register/register.html", context={"register_form":form})

def login_request(request):
    if request.method == "POST":
        form = loginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, "You are now logged in as {username}.")
                return redirect("user_page")
            else:
                messages.error(request, "Invalid username or password.")
        else:
            messages.error(request, "Invalid username or password.")
    form = loginForm()
    return render(request, 'login/login.html',{"login_form": form})

def user_page(request, username):
    if request.method == 'POST':
        user = request.user
        form = accountForm(request.POST, request.FILES, instance=user)
        if form.is_valid():
            user_form = form.save()
            messages.success(request, f'{user_form}, Your profile has been updated!')
            return redirect("user_page", user_form.username)
        for error in list(form.errors.values()):
            messages.error(request, error)
    user = get_user_model().objects.filter(username=username).first()
    if user:
        form = accountForm(instance=user)
        return render(request, 'userpage/userpage.html', context={'form': form})
    return redirect("user_page")

def index(request):
    return HttpResponse("Website under construction")